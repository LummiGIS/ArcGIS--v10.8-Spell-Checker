try:
    '''
    CartTextrophe-An ArcMap Spelling Checker by Gerry Gabrisch GISP
    is licensed under a Creative Commons Attribution 4.0 International License.
    You are free to distribute and alter this code (with attribution).
    Gerry Gabrisch, GISP
    GIS Manager, Lummi Indian Business Council
    2665 Kwina Road
    Bellingham, WA 98226
    geraldg@lummi-nsn.gov
    gerry@gabrisch.us
    Copyright 2017
    
    This tool requires an installation of PyEnchant and Easygui.  Both
    installers (and instructions) are included in the folder that stores
    this toolbox.
    The parent directory for these tools must be stored in a location where
    the user has read/write permissions.
    '''
    
    import sys, traceback
    import os
    import enchant
    import re
    import arcpy
    import easygui
    #print hype
    arcpy.AddMessage("ArcGIS Spell Checker for Layout Items...\nby Gerry Gabrisch, GISP (geraldg@lummi-nsn.gov)")
    arcpy.AddMessage("Licensed under a Creative Commons Attribution 4.0 International License.\n\n\n")
    
    mxd = arcpy.mapping.MapDocument("CURRENT")
    
    #Type Boolean.  If true removes non-alphebetic characters from the front
    #and rear of the word before spell checking.  
    removeEndJunk = arcpy.GetParameter(0)
    #Define the dictionary
    d = enchant.Dict(arcpy.GetParameterAsText(1))
    #Track misspellings
    misspelledWordCounter = 0
    #Get the relative path to the text file that is storing the custom dictionary
    #and write them to a list. Words in the custom dictionary are skipped by the
    #spell checker...
    goodWords = []
    script_dir = os.path.dirname(__file__)
    #This text file needs to be in the same directory as this .py file...
    rel_path = "ListOfWordsToSkip.txt"
    abs_file_path = os.path.join(script_dir, rel_path)
    f= open(abs_file_path, 'a+')
    #Read the custom dictionary text file...
    for line in f:
        line = line[:-1]
        goodWords.append(line)
    
    def CheckSpellingText(word, misspelledWordCounter, f):
        if word in goodWords:
            pass
        else:
            #If the spelling is valid d.check()returns True so do nothing...
            if d.check(word):
                pass
            #A misspelled word returns false so write the word to the window...
            else:
                misspelledWordCounter  += 1
                suggestions = d.suggest(word)
                if suggestions ==[]:
                    addtodictionary = easygui.ynbox('Misspelled word?\nNo Suggestions for:\n' + word, 'Add to custom dictionary?', ('Yes', 'No'))
                    if addtodictionary:
                        f.write(word + '\n')
                        goodWords.append(word)
                else:
                    title = "Choose a replacement or click cancel to skip..."
                    choice = easygui.choicebox(word, title, suggestions)
                    if choice == None:
                        addtodictionary = easygui.ynbox('Misspelled word?\nNo suggestions for:\n' + word, 'Add to custom dictionary?', ('Yes', 'No'))
                        if addtodictionary:
                            f.write(word + '\n')
                            goodWords.append(word)
                    if choice != None:
                            try:
                                elm.text = elm.text.replace(word, choice)
                            except:
                                    print "Can't do it..."
                                    
        return misspelledWordCounter
    
    def CheckSpellingLegendTitle(word, misspelledWordCounter, f):
        if word in goodWords:
            pass
        else:
            #If the spelling is valid d.check()returns True so do nothing...
            if d.check(word):
                pass
            #A misspelled word returns false so write the word to the window...
            else:
                misspelledWordCounter  += 1
                #arcpy.AddMessage("    Misspelled word?: " + word)
                suggestions = d.suggest(word)
                if suggestions ==[]:
                    addtodictionary = easygui.ynbox('Misspelled word?\nNo Suggestions for:\n' + word, 'Add to custom dictionary?', ('Yes', 'No'))
                    if addtodictionary:
                        f.write(word + '\n')
                        goodWords.append(word)
                else:
                    title = "Choose a replacement or click Cancel to skip..."
                    choice = easygui.choicebox(word, title, suggestions)
                    if choice == None:
                        addtodictionary = easygui.ynbox('Misspelled word?\nNo Suggestions for:\n' + word, 'Add to custom dictionary?', ('Yes', 'No'))
                        if addtodictionary:
                            f.write(word + '\n')
                            goodWords.append(word)
                    if choice != None:
                            try:
                                elm.title = elm.title.replace(word, choice)
                            except:
                                    arcpy.AddMessage("Failed on legend title...")
        return misspelledWordCounter
    
    def CheckSpellingMXD(word, misspelledWordCounter, typelistcounter, f):
        try:
            word = word.encode('ascii','ignore')
            if word in goodWords or word =='':
                pass
            else:
                #If the spelling is valid d.check()returns True so do nothing...
                if d.check(word):
                    pass
                else:
                    misspelledWordCounter += 1
                    suggestions = d.suggest(word)
                    if suggestions ==[]:
                        addtodictionary = easygui.ynbox('Misspelled word?\nNo Suggestions for:\n' + word, 'Add to custom dictionary?', ('Yes', 'No'))
                        if addtodictionary:
                            f.write(word + '\n')
                            goodWords.append(word)
                    else:
                        title = "Choose a replacement or click Cancel to skip..."
                        choice = easygui.choicebox(word, title, suggestions)
                        if choice == None:
                            addtodictionary = easygui.ynbox('Misspelled word?\nNo Suggestions for:\n' + word, 'Add to custom dictionary?', ('Yes', 'No'))
                            if addtodictionary:
                                f.write(word + '\n')
                        elif choice != None:
                            if typelistcounter == 0:
                                mxd.summary = mxd.summary.replace(word, choice)
                            elif typelistcounter == 1:
                                mxd.tags = mxd.tags.replace(word, choice)  
                            elif typelistcounter == 2:
                                mxd.title = mxd.title.replace(word, choice)     
                            elif typelistcounter == 3:
                                mxd.description = mxd.description.replace(word, choice)
                            elif typelistcounter == 4:
                                mxd.author = mxd.author.replace(word, choice)     
                            elif typelistcounter == 5:
                                mxd.credits = mxd.credits.replace(word, choice)
                        else:
                            arcpy.AddMessage("wait...nothing happened...")
            return misspelledWordCounter
        except arcpy.ExecuteError: 
            arcpy.AddMessage("error")
            msgs = arcpy.GetMessages(2) 
            arcpy.AddError(msgs)  
            arcpy.AddMessage(msgs)
        except:
            tb = sys.exc_info()[2]
            tbinfo = traceback.format_tb(tb)[0]
            pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
            arcpy.AddMessage(pymsg)
    
    def RemoveLeadingAndTrailngJunk(itemstring):
        #This function removes any non-leter characters from the ends of the
        #string like periods, comma which may result in a misspelling...
        itemstring = re.sub('^[^a-zA-z]*|[^a-zA-Z]*$','',itemstring)
        return itemstring
    ##This checks all title items, and text in the layout view of an MXD.
    arcpy.AddMessage("Checking title, and text in the layout view:\n")
    for elm in arcpy.mapping.ListLayoutElements(mxd, "TEXT_ELEMENT"):
        allwords = elm.text
        #Remove any ESRI dynamic text objects from the string...
        allwords = re.sub('<[^>]+>', '', allwords)
        #Split the string into individual words if there is a space between them...
        allwords = allwords.split(" ")
        for item in allwords:
            #ArcGIS give you the return and new line escape sequences added
            #cast the string to a list and remove it, then rebuild the string...
            words2 =item.split("\r\n")
            for item in words2:
                itemlist = list(item)
                #arcpy.AddMessage(itemlist)
                if len(itemlist) >=2:
                    #just in case there is some left-over escape sequences in the word...
                    if itemlist[-1] == "\n" or itemlist[-1] == "\t": 
                        itemlist = itemlist[:-1]
                        itemstring = "".join(itemlist)
                    else:
                        itemstring = "".join(itemlist) 
                else:
                    itemstring = "".join(itemlist)
                if removeEndJunk:
                    itemstring = RemoveLeadingAndTrailngJunk(itemstring)
                if itemstring =="":
                    pass
                else:
                    itemstring = itemstring.encode('ascii','ignore')
                    misspelledWordCounter = CheckSpellingText(itemstring, misspelledWordCounter, f)  
    
    
    if misspelledWordCounter == 0:
        arcpy.AddMessage("   No misspelled words were found in layout text!")
    
    #This checks legend title text...
    arcpy.AddMessage("\n\nChecking legend title:\n")
    for elm in arcpy.mapping.ListLayoutElements(mxd, "LEGEND_ELEMENT"):
        if elm.title == "":
            pass
        else:
            allwords = elm.title
            cleanwords = []
            allwords =allwords.split("\r\n")
            for item in allwords:
                if " " in item:
                    splititem = item.split(" ")
                    for item2 in splititem:
                        cleanwords.append(item2)
                else:
                    cleanwords.append(item)
            if removeEndJunk:
                for word in cleanwords:
                    word = RemoveLeadingAndTrailngJunk(word)
                    if word =="":
                        pass
                    else:
                        misspelledWordCounter = CheckSpellingLegendTitle(word, misspelledWordCounter, f)
    if misspelledWordCounter == 0:
        arcpy.AddMessage("   No misspelled words were found in legend title!")
  
  #This checks text in document properties...
    arcpy.AddMessage("\n\nChecking map document items (description, tags, summary, title, author, and credits):\n")
    mapdocumentpropertiestext = [mxd.summary, mxd.tags, mxd.title, mxd.description, mxd.author, mxd.credits]
    typelist = ['summary','tags','title','description', 'author','credits']
    typelistcounter = -1
    for items in mapdocumentpropertiestext:
        typelistcounter+=1
        items = items.split(" ")
        for itemstring in items:
            if itemstring == "":
                pass
            else:
                itemstring = itemstring.strip()
            if itemstring == " " or itemstring =="":
                pass
            else:
                if removeEndJunk:
                    itemstring = RemoveLeadingAndTrailngJunk(itemstring)
            misspelledWordCounter = CheckSpellingMXD(itemstring, misspelledWordCounter, typelistcounter, f)
    if misspelledWordCounter == 0:
        arcpy.AddMessage("   No misspelled words were found in the MXD Metadata!")
    
    f.close()
    
    arcpy.AddMessage("\n\nSorry, ESRI will not let me check dataview text items.")
    arcpy.AddMessage("Finished Spell Checking!")
    arcpy.RefreshActiveView()
    del mxd
except arcpy.ExecuteError: 
    arcpy.AddMessage("error")
    msgs = arcpy.GetMessages(2) 
    arcpy.AddError(msgs)  
    arcpy.AddMessage(msgs)
except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
    arcpy.AddMessage(pymsg)