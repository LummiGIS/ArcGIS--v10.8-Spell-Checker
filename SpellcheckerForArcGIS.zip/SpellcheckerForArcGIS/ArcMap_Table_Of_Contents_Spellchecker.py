try:
    '''
    CartTextrophe-An ArcMap Spelling Checker by Gerry Gabrisch GISP
    is licensed under a Creative Commons Attribution 4.0 International License.
    You are free to distribute and alter this code (with attribution).
    Gerry Gabrisch, GISP
    GIS Manager, Lummi Indian Business Council
    2665 Kwina Road
    Bellingham, WA 98226
    geraldg@lummi-nsn.gov
    gerry@gabrisch.us
    Copyright 2017
    
    This tool requires an installation of PyEnchant and Easygui.  Both
    installers (and instructions) are included in the folder that stores
    this toolbox.
    The parent directory for these tools must be stored in a location where
    the user has read/write permissions.
    '''
    
    #import error handler stuff and other Python libraries
    import sys, traceback
    import os
    import re
    import easygui
    import enchant
    import arcpy
    
    
    arcpy.AddMessage("ArcGIS Spell Checker for Layout Items...\nby Gerry Gabrisch, GISP (geraldg@lummi-nsn.gov)")
    arcpy.AddMessage("Licensed under a Creative Commons Attribution 4.0 International License.\n\n\n")
    
    mxd = arcpy.mapping.MapDocument("CURRENT")
    #Get the relative path to the text file that is storing the custom dictionary
    #and write them to a list. Words in the custom dictionary are skipped...
    misspelledWordCounter = 0
    goodWords = []
    script_dir = os.path.dirname(__file__)
    rel_path = "ListOfWordsToSkip.txt"
    abs_file_path = os.path.join(script_dir, rel_path)
    f= open(abs_file_path, 'a+')
    #Read the custom dictionary text file...
    for line in f:
        line = line[:-1]
        goodWords.append(line)
    
    d = enchant.Dict(arcpy.GetParameterAsText(0))
    
    def CheckSpellingLegend(word, misspelledWordCounter, f):
        if word in goodWords:
            pass
        else:
            #If the spelling is valid d.check()returns True so do nothing...
            if d.check(word):
                pass
            #A misspelled word returns false so write the word to the window...
            else:
                misspelledWordCounter  += 1
                suggestions = d.suggest(word)
                if suggestions ==[]:
                    addtodictionary = easygui.ynbox('Misspelled word?\nNo Suggestions for:\n' + word, 'Add to custom dictionary?', ('Yes', 'No'))
                    if addtodictionary:
                        f.write(word + '\n')
                        goodWords.append(word)
                else:
                    title = "Choose a replacement or click Cancel to skip..."
                    choice = easygui.choicebox(word, title, suggestions)
                    if choice == None:
                        addtodictionary = easygui.ynbox('Misspelled word?\nNo Suggestions for:\n' + word, 'Add to custom dictionary?', ('Yes', 'No'))
                        if addtodictionary:
                            f.write(word + '\n')
                            goodWords.append(word)
                    if choice != None:
                            lyr.name = lyr.name.replace(word, choice)
        return misspelledWordCounter
    df = arcpy.mapping.ListDataFrames(mxd)  
    for dframe in df:
        dataframename = dframe.name.encode('ascii','ignore')
        if " " in dataframename:
                    dataframename= dataframename.encode("string-escape")
                    words = ''.join((c if c.isalnum() else ' ') for c in dataframename).split()
                    for word in words:
                        misspelledWordCounter = CheckSpellingLegend(word, misspelledWordCounter, f)
        else:
            misspelledWordCounter = CheckSpellingLegend(dataframename, misspelledWordCounter, f)
        layers = arcpy.mapping.ListLayers(mxd, "", dframe)  
        for lyr in layers:  
            layername = lyr.name.encode('ascii','ignore')
            if " " in layername:
                    layername= layername.encode("string-escape")
                    words = ''.join((c if c.isalnum() else ' ') for c in layername).split()
                    for word in words:
                        misspelledWordCounter = CheckSpellingLegend(word, misspelledWordCounter, f) 
            else:
                misspelledWordCounter = CheckSpellingLegend(layername, misspelledWordCounter, f)
    arcpy.RefreshTOC()    
    arcpy.AddMessage("\n\nFinished Spell Checking!")

except arcpy.ExecuteError: 
    arcpy.AddMessage("error")
    msgs = arcpy.GetMessages(2) 
    arcpy.AddError(msgs)  
    arcpy.AddMessage(msgs)
except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
    arcpy.AddMessage(pymsg)