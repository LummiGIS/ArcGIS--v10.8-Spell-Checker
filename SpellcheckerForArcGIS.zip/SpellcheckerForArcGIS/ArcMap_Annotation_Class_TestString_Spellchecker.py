try:
    import sys, traceback, os
    import enchant
    import arcpy
    import re
    arcpy.AddMessage("ArcGIS Spell Checker for attribute tables...\nby Gerry Gabrisch, GISP (geraldg@lummi-nsn.gov)")
    arcpy.AddMessage("Copy?Right! 2017\n\n\n")
    
    fc = arcpy.GetParameterAsText(0)
    theFieldName = arcpy.GetParameterAsText(1)
    makeSuggestions = arcpy.GetParameter(2)
    d = enchant.Dict(arcpy.GetParameterAsText(3))
    
    #fc = r"Z:\GISpublic\GerryG\PythonScripts\SpellCheckerForArcGIS\testdata\ReservationAnnotation.gdb\MajorGeographicAreas"
    #theFieldName = "TextString"
    #makeSuggestions = True
    #d = enchant.Dict('en_US')
    arcpy.AddMessage(type(makeSuggestions))
    misspelledWordCounter = 0
    goodWords = []
    script_dir = os.path.dirname(__file__)
    rel_path = "ListOfWordsToSkip.txt"
    abs_file_path = os.path.join(script_dir, rel_path)
    f= open(abs_file_path, 'r')
    for line in f:
        line = line[:-1]
        goodWords.append(line)
    def CheckSpelling(word, misspelledWordCounter, makeSuggestions):
        if word in goodWords:
            pass
        else:
            #If the spelling is valid d.check()returns True so do nothing...
            if d.check(word):
                pass
            #A misspelled word returns false so write the word to the window...
            else:
                misspelledWordCounter  += 1
                arcpy.AddMessage("    Misspelled word?: " + word)
                if makeSuggestions:
                    suggestions = d.suggest(word)
                    if suggestions == []:
                        arcpy.AddMessage("          No suggestions.")
                    else:
                        #suggestions = u", ".join(suggestions)
                        arcpy.AddMessage("          Suggestions = ")
                        arcpy.AddMessage(suggestions)
        return misspelledWordCounter
    fields = [theFieldName]
    uniqueWords = []
    with arcpy.da.SearchCursor(fc, fields) as cursor:
        for row in cursor:
            counter = 0
            theattributevalue = str((row[0]))
            theattributevalue =  theattributevalue = theattributevalue.replace('\r\n', " ")
            theattributevalue= theattributevalue.split(" ")
            for word in theattributevalue:
                if word =="" or word == " ":
                    pass
                else:
                    misspelledWordCounter = CheckSpelling(word, misspelledWordCounter, makeSuggestions)
    f.close()
    if misspelledWordCounter == 0:
        arcpy.AddMessage("No misspelled words were found in layout text, the title, or the legend!")
    arcpy.AddMessage("\n\nFinished Without Error!")
except arcpy.ExecuteError: 
    print "error"
    msgs = arcpy.GetMessages(2) 
    arcpy.AddError(msgs)  
    print msgs
except:
    print "error"
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
    print pymsg + "\n"